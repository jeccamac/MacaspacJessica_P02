MacaspacJessica_P02

CONTROL SCHEME
	
	Move: WASD
	Jump: Space
	Sprint: Left-Shift
	Pause: ESC
	
DIFFICULTIES
	I had some problems with attaching the Mouse Sensitivity and the Volume to the sliders in the Pause Menu. The sliders work fine by themselves but when attached, it doesn't drag or move with the value.
